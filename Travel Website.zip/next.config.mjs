// next.config.js

/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['test-2.e2l.tech'],
  },
};

export default nextConfig;
